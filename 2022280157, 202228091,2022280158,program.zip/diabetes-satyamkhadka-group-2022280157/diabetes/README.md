# early stage diabetes-prediction

Currenly using few models to predict diabetes prediction. 

there's gui.py file to test if you are a probable diabetes patient or not. 

Although the models are highly accurate, it is advised to visit a registered doctor to have yourself checkedup XD  


# how to run the program:
  ```shell
  python gui.py
  ```
  
contact me : contact@satyamkhadka.com.np
project for datamining@NWPU 
